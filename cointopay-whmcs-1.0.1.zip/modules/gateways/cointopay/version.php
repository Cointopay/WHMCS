<?php

define('COINTOPAY_PLUGIN_VERSION', '1.0.1');